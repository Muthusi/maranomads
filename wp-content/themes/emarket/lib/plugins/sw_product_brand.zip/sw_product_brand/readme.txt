Plugin Sw Product Brand

== author: WpThemeGo
== Author Link: http://www.wpthemego.com/
== Description: Sw product brand help customer can choose product brand and show multilayout brand on the page which you want.